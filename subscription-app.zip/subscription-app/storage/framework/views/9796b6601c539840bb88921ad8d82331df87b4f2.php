<!DOCTYPE html>
<html>
	<head>
	    <title>New Post Published</title>
	</head>
	<body style="margin: 20px auto;max-width: 800px;">

	    <h1 style="font-size: 36px;color: #444;font-family:Georgia"><?php echo e($post->title); ?></h1>
	    <div style="font-size: 18px;color: #444;margin-bottom:20px;font-family:Georgia;line-height:1.5;">
	    	<?php echo e($post->description); ?>     
      </div>

	    <hr>	 
	    <br>  	
	    <p style="font-size: 18px;font-family:Georgia;margin-bottom:0;">Thank you</p>
	    <p style="font-size: 14px;font-family:Georgia;margin-top:5px;color:#888">Sample Subscription Application</p>

	</body>
</html>