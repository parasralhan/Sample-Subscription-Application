<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <link href="/css/app.css" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 400;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: left;
            }

            .title {
                font-weight: 100;
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .mb-2 {
                margin-bottom: 20px;
            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <div class="content">
                <div class="title m-b-md">
                    Create Post
                </div>

                <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>

                <div class="form">
                  
                  <form method="POST" action="/posts/create">

                    <?php echo csrf_field(); ?>                    

                    <div class="mb-2">
                      <label for="title">Post Title</label>
                      <input class="form-control" type="text" id="title" name="title" value="<?php echo e(old('title')); ?>">

                      <?php if($errors->first('title')): ?>
                          <div class="alert alert-danger">
                          <?php echo e($errors->first('title')); ?> 
                          </div>
                      <?php endif; ?>  

                    </div>

                    <div class="mb-2">
                      <label for="title">Post Description</label>
                      <textarea class="form-control" name="description" id="description" cols="30" rows="10"><?php echo e(old('description')); ?></textarea>

                      <?php if($errors->first('description')): ?>
                          <div class="alert alert-danger">
                          <?php echo e($errors->first('description')); ?> 
                          </div>
                      <?php endif; ?>  

                    </div>

                    <button type="submit" class="btn btn-primary">
                      Create
                    </button>

                  </form>

                </div>


            </div>
        </div>
    </body>
</html>
