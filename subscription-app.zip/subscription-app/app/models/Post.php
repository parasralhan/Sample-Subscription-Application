<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Post extends Model {	

	protected $table = 'posts';

	protected $fillable = ['title', 'description'];
	
	public function __construct() {
		
		

	}

}