<?php

namespace App\Listeners;

use App\Events\PostCreated;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\models\Subscriber;
use Illuminate\Support\Facades\Mail;
use App\Mail\SendMail;

class SendPostCreatedNotification
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  PostCreated  $event
     * @return void
     */
    public function handle(PostCreated $event)
    {
        $post = $event->post;

        foreach ( Subscriber::all() as $subscriber ) {
            Mail::to($subscriber->email)->send(new SendMail($post) );
        }
    }
}
