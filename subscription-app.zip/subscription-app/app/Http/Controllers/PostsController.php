<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\models\Post;
use App\models\Subscriber;
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Mail\SendMail;
use Illuminate\Support\Facades\Mail;
use App\Events\PostCreated;

class PostsController extends Controller {

	public function newPost() {

    return view('posts.new');

  }

  public function create ( Request $request ) {

  	$post = new Post;

  	$posted_data = $request->all();

    $validator = Validator::make($posted_data, [
        'title' => 'required|unique:posts|max:255',
        'description' => 'required|max:4000',
    ]);

    if ( $validator->fails() ) {
        return redirect('posts/new')
                    ->withErrors($validator)
                    ->withInput();
    }


  	$post->title = $posted_data['title'];
  	$post->description = $posted_data['description'];

  	$post->save();

    $record = Post::latest()->first();

    $this->notifySubscribers( $record );

  	return redirect()->back()->with('status', 'Post Created!');;

  }

  public function notifySubscribers( Post $post ) {

    foreach ( Subscriber::all() as $subscriber ) {
        // Mail::to($subscriber->email)->queue(new SendMail($post) );
    }    

  }
    
}
