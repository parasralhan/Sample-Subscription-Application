<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\models\Subscriber;
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class SubscriptionController extends Controller {

	public function index() {

    return view('subscribe');

  }

  public function make ( Request $request ) {

  	$post = new Subscriber;

  	$posted_data = $request->all();


  	$validator = Validator::make($request->all(), [
        'email' => 'required|unique:subscribers|email:rfc,dns|max:255',
    ]);

    if ( $validator->fails() ) {
        return redirect('subscribe')
                    ->withErrors($validator)
                    ->withInput();
    }


  	$post->email = $posted_data['email'];

  	$post->save();

  	return redirect()->back()->with('status', 'Thanks for subscribing!');



  }
    
}
