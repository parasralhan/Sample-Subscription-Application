<?php

use Illuminate\Database\Seeder;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Carbon\Carbon;

class PostsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run() {

    	for ($i=0; $i < 50; $i++) { 

        DB::table('posts')->insert([
            'title' => Str::random(10),
            'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pellentesque ante in vestibulum faucibus. Duis sit amet rutrum magna, ut ornare est. Suspendisse potenti. Integer non tincidunt metus. Quisque egestas lorem in pharetra interdum. Vestibulum eros nisl, sodales vel ipsum sit amet, pellentesque suscipit turpis. Suspendisse feugiat, leo eu placerat dictum, orci lacus euismod ex, sit amet efficitur erat risus vel nunc. Phasellus pretium urna quis accumsan eleifend. In fringilla ipsum quis venenatis tempus.',
            'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
            'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
        ]);

     }

    }
}
